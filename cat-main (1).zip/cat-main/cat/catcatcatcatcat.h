#pragma once

namespace cat
{
	PVOID catcatcatcatcatcatcatcatcatcatcat(const char* moduleName);
	bool catcatcatcatcatcatcatcatcatcatcatcat(const char* base, const char* pattern, const char* mask);
	PVOID catcatcatcatcatcatcatcatcatcatcatcatcat(PVOID base, int length, const char* pattern, const char* mask);
	PVOID catcatcatcatcatcatcatcatcatcatcatcatcatcat(PVOID base, const char* pattern, const char* mask);
	void catcatcatcatcatcatcatcatcatcatcatcatcatcatcat(char* text, const int length);
}
