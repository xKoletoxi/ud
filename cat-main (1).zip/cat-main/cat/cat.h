#pragma once

namespace cat
{
	PDEVICE_OBJECT catcatcatcatcatcatcat(const wchar_t* deviceName);
	NTSTATUS catcatcatcatcatcat(PDEVICE_OBJECT deviceArray, RaidUnitRegisterInterfaces registerInterfaces);
	NTSTATUS cat();
	NTSTATUS catcat();
	void catcatcatcatcatcatcatcat(PRAID_UNIT_EXTENSION extension);
}