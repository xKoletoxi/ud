


#include "catcatcatcatcatcat.h"
#include "catcatcatcat.h"
#include "catcatcat.h"

#include "cat.h"
#include "catcat.h"

#define catcatcatcatcatcatcat 0x00000000L

// cat
extern "C" NTSTATUS catttt(PDRIVER_OBJECT catcatcatcatcat, PUNICODE_STRING catcatcatcat)
{
	UNREFERENCED_PARAMETER(catcatcatcatcat);
	UNREFERENCED_PARAMETER(catcatcatcat);

	cat::catcat();
	cat::cat();
	cat::catcatcat();

	return catcatcatcatcatcatcat;
}