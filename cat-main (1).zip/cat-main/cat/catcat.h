#pragma once

namespace cat
{
	char* catcatcatcatcatcatcatcatcatttttttcatcattttttttt(SMBIOS_HEADER* header, SMBIOS_STRING string);
	void catcatcatcatcatcatcatcatcattttttt(char* string);
	NTSTATUS catcatcatcatcatcatcatcatcatttttttcatcatttt(SMBIOS_HEADER* header);
	NTSTATUS catcatcatcatcatcatcatcatcatttttttcatcatt(void* mapped, ULONG size);
	NTSTATUS catcatcat();
}