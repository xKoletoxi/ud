#pragma once

namespace cat
{
	void catctatttttttttttttttttttttttttttt(const char* text, ...);
}